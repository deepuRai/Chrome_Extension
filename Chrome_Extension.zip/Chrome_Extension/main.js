const request = async () => {
    const response = await fetch('https://newsapi.org/v2/top-headlines?country=us&apiKey=c33dc310790b42beb252567a39a47d3a');
    const json = await response.json();
    console.log(json);
}

request();

